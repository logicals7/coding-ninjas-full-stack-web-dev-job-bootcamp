package Cn.CartApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CartAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
