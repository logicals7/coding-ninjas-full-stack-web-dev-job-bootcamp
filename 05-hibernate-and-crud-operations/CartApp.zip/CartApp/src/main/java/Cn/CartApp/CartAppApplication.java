package Cn.CartApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CartAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(CartAppApplication.class, args);
	}

}
